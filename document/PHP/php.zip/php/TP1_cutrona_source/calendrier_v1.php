<?php
$html = <<<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <title>Calendrier</title>
      <link href="/ressources/css/php.css" rel="stylesheet" type="text/css">
      <style type='text/css'>
      table#calendrier {
        background-color : transparent ;
        border-spacing  : 0 ;
        border-collapse : collapse ;
      }
      table#calendrier td, table#calendrier th {
        background-color : transparent ;
        text-align : right ;
        padding : 0.2em ;
        width : 1.5em ;
        height : 1.5em ;
        border-right : solid 1px black ;
        border-left : solid 1px black ;
      }
      table#calendrier th {
        text-align : center ;
        background-color : #DDD ;
      }
      table#calendrier td.weekend {
        background-color : #9D9 ;
      }
      </style>
    </head>
    <body>
    <div id='page'>
    <h1>Calendrier</h1>
        <table id='calendrier'>
HTML;
setlocale(LC_ALL, 'fr_FR.utf8') ;
$semaine = array('L', 'M', 'M', 'J', 'V', 'S', 'D') ;
$date = mktime(0,0,0, date("n"), 1, date("Y")) ;
$nom_mois = strftime("%B %Y", $date) ;
$premier_jour_mois = date('N', $date)-1 ;
$nombre_jours_mois = date('t', $date) ;
$colonne_courante = 0 ;

$html .= "<tr><th colspan='7'>$nom_mois<tr>" ;
// Première ligne
foreach ($semaine as $i => $jour) {
    $html .= "<th>$jour" ;
}
if ($premier_jour_mois > 0) {
    $html .= "<tr>" ;
    for ($colonne_courante=0; $colonne_courante<$premier_jour_mois; $colonne_courante++) {
        $html .= "<td>" ;
    }
}

for ($jour_courant=1; $jour_courant <= $nombre_jours_mois; $jour_courant++, $colonne_courante++)
{
    if ($colonne_courante % 7 == 0) {
        $html .= "<tr>\n" ;
    }
    $class = ($colonne_courante%7==5 || $colonne_courante%7==6) ? " class='weekend'" : "" ;
    $html .= "<td{$class}>$jour_courant" ;
}

while ($colonne_courante % 7) {
    $html .= "<td>" ;
    $colonne_courante++ ;
}

$html .= "</table>\n" ;

////$html .= piedDePage() ;

$html .= <<<HTML
    </div>
    </body>
</html>
HTML;

echo $html ;
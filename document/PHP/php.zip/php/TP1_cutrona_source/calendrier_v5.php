<?php
function datePaques($annee, &$moisPaques, &$jourPaques) {
    $G = $annee % 19 ;
    $C = floor($annee / 100) ;
    $Csur4 = floor($C / 4) ;
    $E = floor((8 * $C + 13) / 25) ;
    $H = (19 * $G + $C - $Csur4 - $E + 15) % 30 ;
    if ($H == 29) {
        $H = 28 ;
    }
    else if ($H == 28 && $G > 10) {
        $H = 27 ;
    }
    $K = floor($H / 28) ;
    $P = floor(29 / ($H + 1)) ;
    $Q = floor((21 - $G) / 11) ;
    $I = ($K*$P*$Q - 1)*$K + $H ;
    $B = floor($annee/4) + $annee;
    $J = ($B + $I + 2 + $Csur4 - $C) % 7 ;
    $R = 28 + $I - $J ;
    $moisPaques = $R > 30 ? 4 : 3 ;
    $jourPaques = $moisPaques == 3 ? $R : $R-31 ;
}

function jourFerie($jour, $mois, $annee) {
    if ($jour == 1  && $mois == 1 ) return true ;
    if ($jour == 1  && $mois == 5 ) return true ;
    if ($jour == 8  && $mois == 5 ) return true ;
    if ($jour == 14 && $mois == 7 ) return true ;
    if ($jour == 11 && $mois == 11) return true ;
    if ($jour == 15 && $mois == 8 ) return true ;
    if ($jour == 1  && $mois == 11) return true ;
    if ($jour == 25 && $mois == 12) return true ;
    if ($mois == 3 || $mois <= 6) {
        datePaques($annee, $moisPaques, $jourPaques) ;
        // Lundi de Pâques (1 jour après Pâques)
        $moisLundiPaques = $moisPaques ;
        $jourLundiPaques = $jourPaques + 1 ;
        if ($jourLundiPaques == 32) {
            $jourLundiPaques = 1 ;
            $moisLundiPaques++ ;
        }
        if ($jour == $jourLundiPaques && $mois == $moisLundiPaques) return true ;
        // Jeudi de l'Ascension (39 jours après Pâques)
        $moisJeudiAscension = $moisPaques ;
        $jourJeudiAscension = $jourPaques + 39 ;
        if ($moisJeudiAscension == 3 && $jourJeudiAscension > 31) {
            $moisJeudiAscension++ ;
            $jourJeudiAscension -= 31 ;
        }
        if ($moisJeudiAscension == 4 && $jourJeudiAscension > 30) {
            $moisJeudiAscension++ ;
            $jourJeudiAscension -= 30 ;
        }
        if ($jour == $jourJeudiAscension && $mois == $moisJeudiAscension) return true ;
        // Lundi de Pentecôte (50 jours après Pâques)
        $jourLundiPentecote = $jourJeudiAscension + 11 ;
        $moisLundiPentecote = $moisJeudiAscension ;
        if ($moisLundiPentecote == 4 && $jourLundiPentecote > 30) {
            $moisLundiPentecote++ ;
            $jourLundiPentecote -= 30 ;
        }
        if ($moisLundiPentecote == 5 && $jourLundiPentecote > 31) {
            $moisLundiPentecote++ ;
            $jourLundiPentecote -= 31 ;
        }
        if ($jour == $jourLundiPentecote && $mois == $moisLundiPentecote) return true ;
    }
}

function calendrier($mois, $annee, $afficheAnnee=false) {
    if ($annee < 1583) {
        throw new Exception("Calendrier invalide avant 1583") ;
    }
    setlocale(LC_ALL, 'fr_FR.utf8') ;
    $semaine = array('L', 'M', 'M', 'J', 'V', 'S', 'D') ;
    $date = mktime(0,0,0, $mois, 1, $annee) ;
    $nom_mois = strftime($afficheAnnee ? "%B %Y" : "%B", $date) ;
    $premier_jour_mois = date('N', $date)-1 ;
    $nombre_jours_mois = date('t', $date) ;
    $colonne_courante = 0 ;

    $html = <<<HTML

            <table class='calendrier'>
            <tr><th colspan='7'>$nom_mois
            <tr>

HTML;
    // Première ligne
    foreach ($semaine as $i => $jour) {
        $html .= "<th>$jour" ;
    }
    if ($premier_jour_mois > 0) {
        $html .= "\n<tr>" ;
        while ($colonne_courante<$premier_jour_mois) {
            $html .= "<td>" ;
            $colonne_courante++ ;
        }
    }

    for ($jour_courant=1; $jour_courant <= $nombre_jours_mois; $jour_courant++, $colonne_courante++)
    {
        if ($colonne_courante % 7 == 0) {
            $html .= "\n<tr>" ;
        }
        $class = array() ;
        if ($colonne_courante%7==5 || $colonne_courante%7==6) {
           $class[] = 'weekend' ;
        }
        if (jourFerie($jour_courant, $mois, $annee)) {
           $class[] = 'ferie' ;
        }
        if (count($class)) {
            $class = " class='" . implode($class, " ") . "'" ;
        }
        else {
            $class = "" ;
        }
        $html .= "<td{$class}>$jour_courant" ;
    }

    while ($colonne_courante % 7) {
        $html .= "<td>" ;
        $colonne_courante++ ;
    }
    $html.="</table>" ;

    return $html ;
}
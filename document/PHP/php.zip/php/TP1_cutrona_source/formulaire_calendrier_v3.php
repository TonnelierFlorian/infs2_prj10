<?php
$html = <<<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <title>Choix d'un mois et d'une année</title>
      <link href="/ressources/css/php.css" rel="stylesheet" type="text/css">
      <script type="text/javascript">
        function controle(monFormulaire) {
            var valide = false ;
            if (monFormulaire.m.selectedIndex == 0) {
                window.alert("Merci de choisir un mois.") ;
            }
            else if (monFormulaire.a.selectedIndex == 0) {
                window.alert("Merci de choisir une année.") ;
            }
            else {
                valide = true ;
            }
            return valide ;
        }
      </script>
    </head>
    <body>
    <div id='page'>
    <h1>Choix d'un mois et d'une année</h1>
<fieldset><legend>Choisissez un mois et une année</legend>
    <form action='calendrier_v3.php' method='GET' onSubmit="return controle(this)">
    <select name="m">
        <option value="0">Mois

HTML;
// Affichage des mois en toutes lettres
/* Version naïve
$mois = array(1=>'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre') ;
foreach ($mois as $k => $m)
{
    $html .= "<option value='$k'>$m\n" ;
}
*/
// ou version "évoluée" : 
// Demande de formatage des dates en français
setlocale(LC_TIME, "fr_FR.UTF-8") ;
for ($m=1; $m<=12; $m++)
    $html .= "        <option value='$m'>".mb_convert_case(strftime("%B", mktime(0, 0, 0, $m)), MB_CASE_TITLE, "utf-8")."\n" ;
    /*                                     ^               ^              ^
     *                                     |               |              --Creation d'une date au mois $m
     *                                     |               --Formatage de la date (%B : mois en toutes lettres)
     *                                     --Premiere lettre en majuscules avec MB_CASE_TITLE
     */

$html .= <<<HTML
    </select>
    <select name='a'>
        <option value="0">Année\n
HTML;

// Affichage des années
for ($a=date('Y')+1; $a>=1900; $a--)
    $html .= "        <option>$a\n" ;

    $html .= <<<HTML
      </select>
    <input type="submit" value="Voir le calendrier">
    </form>
</fieldset>
HTML;
//$html .= piedDePage() ;
$html .= <<<HTML
    </div>
    </body>
</html>
HTML;

echo $html ;
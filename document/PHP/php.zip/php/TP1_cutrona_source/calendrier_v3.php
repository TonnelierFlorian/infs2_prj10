<?php

require "calendrier.function.php" ;

$annee = date('Y') ;
if (isset($_GET['a']) && !empty($_GET['a']) && ctype_digit($_GET['a'])) {
    $annee = (int) $_GET['a'] ;
}
$mois = date('m') ;
if (isset($_GET['m']) && !empty($_GET['m']) && ctype_digit($_GET['m']) && $_GET['m'] > 0 && $_GET['m'] <= 13) {
    $mois = (int) $_GET['m'] ;
}

$html = <<<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <title>Calendrier</title>
      <link href="/ressources/css/php.css" rel="stylesheet" type="text/css">
      <style type='text/css'>
      .annee {
        text-align : center ;
      }
      table.calendrier {
        display : inline-block ;
        background-color : transparent ;
        border-spacing  : 0 ;
        border-collapse : collapse ;
        vertical-align : text-top ;
        margin : 0.3em ;
        border-top : solid 1px black ;
      }
      table.calendrier td, table.calendrier th {
        background-color : transparent ;
        text-align : right ;
        padding : 0.2em ;
        width : 1.5em ;
        height : 1.5em ;
        border-right : solid 1px black ;
        border-left : solid 1px black ;
      }
      table.calendrier th {
        text-align : center ;
        background-color : #DDD ;
      }
      table.calendrier td.weekend {
        background-color : #9D9 ;
      }
      </style>
    </head>
    <body>
    <div id='page'>
    <h1>Calendrier {$mois}/{$annee}</h1>
    <div class='annee'>
HTML;
    $html .= calendrier($mois, $annee, true) ;

//$html .= piedDePage() ;

$html .= <<<HTML
    </div>
    </div>
    </body>
</html>
HTML;

echo $html ;
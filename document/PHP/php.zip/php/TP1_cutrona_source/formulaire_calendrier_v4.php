<?php
$html = <<<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <title>Choix d'une année</title>
      <link href="/ressources/css/php.css" rel="stylesheet" type="text/css">
      <script type="text/javascript">
        function controle(monFormulaire) {
            var valide = false ;
            if (monFormulaire.a.selectedIndex == 0) {
                window.alert("Merci de choisir une année.") ;
            }
            else {
                valide = true ;
            }
            return valide ;
        }
      </script>
    </head>
    <body>
    <div id='page'>
    <h1>Choix d'une année</h1>
<fieldset><legend>Choisissez une année</legend>
    <form action='calendrier4.php' method='GET' onSubmit="return controle(this)">
    <select name='a'>
        <option value="0">Année\n
HTML;

// Affichage des années
for ($a=date('Y')+1; $a>=1900; $a--)
    $html .= "        <option>$a\n" ;

    $html .= <<<HTML
      </select>
    <input type="submit" value="Voir le calendrier">
    </form>
</fieldset>
HTML;
//$html .= piedDePage() ;
$html .= <<<HTML
    </div>
    </body>
</html>
HTML;

echo $html ;
<?php
$html = <<<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <title>Table de Pythagore</title>
      <link href="/ressources/css/php.css" rel="stylesheet" type="text/css">
      <style type='text/css'>
      table#pythagore {
        background-color : transparent ;
        border-spacing  : 0 ;
        border-collapse : collapse ;
      }
      table#pythagore td, table#pythagore th {
        background-color : transparent ;
        text-align : right ;
        padding : 0.2em ;
      }
      </style>
    </head>
    <body>
    <div id='page'>
    <h1>Table de Pythagore</h1>
        <table id='pythagore'>
          <tr><th>&times;\n
HTML;
// Première ligne
for ($colonne=0; $colonne<=10; $colonne++) {
    $html .= "<th>$colonne" ;
}
// Les lignes de multiplication
for ($ligne=0; $ligne<=10; $ligne++)
{
    $html .= "<tr><th>$ligne" ;
    // Les colonnes de multiplication
    for ($colonne=0; $colonne<=10; $colonne++) {
        $html .= "<td>" . ($ligne*$colonne) ;
    }
}
$html .= "</table>\n" ;

//$html .= piedDePage() ;

$html .= <<<HTML
    </div>
    </body>
</html>
HTML;

echo $html ;
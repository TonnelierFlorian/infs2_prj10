<?php
$html = <<<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <title>Table de Pythagore</title>
      <link href="/ressources/css/php.css" rel="stylesheet" type="text/css">
      <style type='text/css'>
      table#pythagore {
        background-color : transparent ;
        border-spacing  : 0 ;
        border-collapse : collapse ;
      }
      table#pythagore td, table#pythagore th {
        background-color : transparent ;
        text-align : right ;
        padding : 0.2em ;
        width : 1.5em ;
        height : 1.5em ;
        border : solid 1px black ;
      }
      table#pythagore tr td.impaire,
      table#pythagore tr th.impaire {
        background-color : #99E ;
      }
      table#pythagore tr.impaire td,
      table#pythagore tr.impaire th {
        background-color : #9E9 ;
      }
      table#pythagore tr.impaire td.impaire {
        background-color : #9EE ;
      }
      </style>
    </head>
    <body>
    <div id='page'>
    <h1>Table de Pythagore</h1>
        <table id='pythagore'>
          <tr><th>&times;\n
HTML;
define("indice_max", 10) ;

// Première ligne
for ($colonne=0; $colonne<=indice_max; $colonne++) {
    // Parité des colonnes
    if ($colonne % 2) {
        $class = "" ;
    }
    else {
        $class = " class='impaire'" ;
    }
    $html .= "<th{$class}>$colonne" ;
}
// Les lignes de multiplication
for ($ligne=0; $ligne<=indice_max; $ligne++)
{
    // Parité des lignes
    if ($ligne % 2) {
        $class = "" ;
    }
    else {
        $class = " class='impaire'" ;
    }
    $html .= "<tr{$class}><th>$ligne" ;
    // Les colonnes de multiplication
    for ($colonne=0; $colonne<=indice_max; $colonne++) {
        // Parité des colonnes
        if ($colonne % 2) {
            $class = "" ;
        }
        else {
            $class = " class='impaire'" ;
        }
        $html .= "<td{$class}>" . ($ligne*$colonne) ;
    }
}
$html .= "</table>\n" ;

//$html .= piedDePage() ;

$html .= <<<HTML
    </div>
    </body>
</html>
HTML;

echo $html ;
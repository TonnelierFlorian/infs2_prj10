<?php
$html = <<<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <title>Table de multiplication d'un nombre</title>
      <link href="/ressources/css/php.css" rel="stylesheet" type="text/css">
      <style type='text/css'>
      table {
        border-spacing  : 0 ;
        border-collapse : collapse ;
      }
      td.nombre {
        text-align : right ;
      }
      </style>
    </head>
    <body>
    <div id='page'>
HTML;

$nb = 12 ;
$html .= <<<HTML
    <h1>Table de multiplication de {$nb}</h1>
    <table>\n
HTML;
// Les lignes de multiplication
for ($i=0; $i<=10; $i++)
{
    $html .= "<tr><td class='nombre'>$i&nbsp;&times;&nbsp;$nb&nbsp;=&nbsp;<td class='nombre'>".($i*$nb)."\n" ;
}
$html .= "</table>\n" ;

//$html .= piedDePage() ;

$html .= <<<HTML
    </div>
    </body>
</html>
HTML;

echo $html ;
<?php

require "calendrier.function.php" ;

$annee = date('Y') ;
if (isset($_GET['a']) && !empty($_GET['a']) && ctype_digit($_GET['a'])) {
    $annee = (int) $_GET['a'] ;
}

$next = $annee + 1 ;
$prev = $annee - 1 ;

$html = <<<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <title>Calendrier {$annee}</title>
      <link href="/ressources/css/php.css" rel="stylesheet" type="text/css">
      <style type='text/css'>
      .annee {
        margin : auto ;
        text-align : center ;
        width : 940px ;
      }
      table.calendrier {
        display : inline-block ;
        background-color : transparent ;
        border-spacing  : 0 ;
        border-collapse : collapse ;
        vertical-align : text-top ;
        margin : 0.3em ;
        border-top : solid 1px black ;
      }
      table.calendrier td, table.calendrier th {
        background-color : transparent ;
        text-align : right ;
        padding : 0.2em ;
        width : 1.5em ;
        height : 1.5em ;
        border-right : solid 1px black ;
        border-left : solid 1px black ;
      }
      table.calendrier th {
        text-align : center ;
        background-color : #DDD ;
      }
      table.calendrier td.weekend {
        background-color : #9D9 ;
      }
      #prev, #next {
        width : 35px ;
        height : 200px ;
        background-color : gray ;
        position : absolute ;
      }
      #prev {
        left : 0 ;
      }
      #next {
        right : 0 ;
      }
      #prev a, #next a {
        display : block ;
        width : 100% ;
        height : 100% ;
        background-repeat : no-repeat ;
        background-position : center center ;
      }
      #next a {
        background-image : url('next.png') ;
      }
      #prev a {
        background-image : url('prev.png') ;
      }
      </style>
    </head>
    <body>
    <div id='page'>
    <h1>Calendrier {$annee}</h1>
<div id='prev'><a href='?a=$prev'></a></div>
<div id='next'><a href='?a=$next'></a></div>
    <div class='annee'>
HTML;
for ($mois = 1; $mois <= 12; $mois++) {
    $html .= calendrier($mois, $annee) ;
}

//$html .= piedDePage() ;

$html .= <<<HTML
    </div>
    </div>
    </body>
</html>
HTML;

echo $html ;
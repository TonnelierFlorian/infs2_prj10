<?php
$html = <<<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <title>Liste à choix multiples</title>
      <link href="/ressources/css/php.css" rel="stylesheet" type="text/css">
      <style type="text/css">
        label {
            display : block ;
        }
      </style>
    </head>
    <body>
    <div id='page'>
    <h1>Les jours de la semaine</h1>
    <form action='' method='GET'>
HTML;

$les_jours = array("lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche") ;
// Pour chaque jour de la semaine
foreach($les_jours as $jour) {
    $html .= <<<HTML
        <label><input type="radio" name="jour" value="$jour">$jour</label>\n
HTML;
}

$html .= <<<HTML
    </form>
HTML;
//$html .= piedDePage() ;
$html .= <<<HTML
    </div>
    </body>
</html>
HTML;

echo $html ;
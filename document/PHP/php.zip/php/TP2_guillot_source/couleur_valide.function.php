<?php
	function couleur_valide($chaine){
		$size = strlen($chaine);
		$res = false;
		if( $size==6 || $size==3){
			$res = mb_ereg_match('[A-Za-z0-9]{6}|[A-Za-z0-9]{3}',$chaine);
		}
		return $res;
	}
	
	/*$i = '3D1';
	$res = couleur_valide($i);
	if($res){$res = 'true';}
	else{$res = 'false';}
	
	echo $i.','.$res;*/
?>
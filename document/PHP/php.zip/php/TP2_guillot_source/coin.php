<?php
require_once 'couleur_valide.function.php' ;

define('taille_max', 300) ;
define('taille_defaut', 100) ;
define('couleur_defaut', '000000') ;

// Récupération d'une couleur
$couleur = isset($_GET['c']) && couleur_valide($_GET['c']) ? $_GET['c'] : couleur_defaut ;
// Récupération d'une taille
$taille  = isset($_GET['t']) && ctype_digit($_GET['t']) ? min($_GET['t'], taille_max) : taille_defaut ;
// Symétrie selon X
$rx = isset($_GET['x']) ;
// Symétrie selon Y
$ry = isset($_GET['y']) ;

// Eclatement de la couleur en ses 3 composantes
if (mb_eregi('^([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$', $couleur, $regs)) {
    $rouge = intVal($regs[1], 16) ;
    $vert  = intVal($regs[2], 16) ;
    $bleu  = intVal($regs[3], 16) ;
    $im = imageCreateTrueColor($taille, $taille) ;
    imageSaveAlpha($im, true) ;
    imageAlphaBlending($im, true) ;
    $fond = imageColorAllocateAlpha($im, 255, 255, 255, 127) ;
    imageFill($im, 0, 0, $fond) ;
    // Construction du dégradé
    $dist_max = round(M_SQRT2 * ($taille-1)) ;
    for ($j=0; $j<$taille; $j++) {
        for ($i=0; $i<$taille; $i++) {
            $x = $rx ? $taille-1-$i : $i ;
            $y = $ry ? $taille-1-$j : $j ;
            $dist = round(sqrt($i*$i+$j*$j)) ;
            $t = min(127, max(0, 127 - round(127 * ($dist-$taille)/($dist_max-$taille)))) ;
            $c = imageColorAllocate($im, $t, $t, $t) ;
            $c = imageColorAllocateAlpha($im, $rouge, $vert, $bleu, $t) ;
            imageSetPixel($im, $x, $y, $c) ;
        }
    }

    header('Content-Type: image/png') ;
    imagePNG($im) ;
    imageDestroy($im) ;
}
else {
    header('Content-Type: image/png') ;
}

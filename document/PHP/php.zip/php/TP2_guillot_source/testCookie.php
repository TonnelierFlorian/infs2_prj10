<?php

	//setcookie('prefCouleur','0');
	
	require_once 'themes.include.php' ;
	require_once 'testCouleur.php';

	function envoyerCookie($theme){
		for($i = 1; $i<=4; $i++){
			setCookie('couleur'.$i,'$theme[\'c'.$i.'\']');
		}

	}

	function lireCookies(&$c1,&$c2,&$c3,&$c4){
		if(isset($_COOKIE['couleur1'])){
			$c1 = $_COOKIE['couleur1'];
			$c2 = $_COOKIE['couleur2'];
			$c3 = $_COOKIE['couleur3'];
			$c4 = $_COOKIE['couleur4'];
		}

	}
?>
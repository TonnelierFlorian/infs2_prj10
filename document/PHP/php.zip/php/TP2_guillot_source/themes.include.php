<?php
/* http://colorschemedesigner.com/ */

$themes = array(
    array('c1' => 'FFFFFF',
          'c2' => 'A0A0A0',
          'c3' => '000000',
          'c4' => '303030'),
    array('c1' => 'ff4f00',
          'c2' => 'ff9500',
          'c3' => 'E7003E',
          'c4' => '00AC6B'),
    array('c1' => 'E1801A',
          'c2' => 'E1B71A',
          'c3' => '3321B1',
          'c4' => '1783A7'),
    array('c1' => 'FFAD56',
          'c2' => 'FFDB56',
          'c3' => '6756DD',
          'c4' => '4BB3D5'),
    array('c1' => 'C100C1',
          'c2' => 'FF0000',
          'c3' => '00DC00',
          'c4' => 'CEF900'),
    array('c1' => '4938DD',
          'c2' => 'B02DDA',
          'c3' => '2BB0D5',
          'c4' => 'FFD230'),
    array('c1' => 'FFA700',
          'c2' => 'FFE500',
          'c3' => 'FF4100',
          'c4' => '0C4AC4')
) ;



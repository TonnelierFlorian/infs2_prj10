<?php

session_start();

require_once 'themes.include.php' ;

$i = 0;
if(isset($_COOKIE['prefCouleur'])){
	$i = $_COOKIE['prefCouleur'];
	$i =(int)$i;
	if($i<0 || $i>7){$i=0;}
}
$couleur1 = $themes[$i]['c1'] ;
$couleur2 = $themes[$i]['c2'] ;
$couleur3 = $themes[$i]['c3'] ;
$couleur4 = $themes[$i]['c4'] ;

header('Content-type: text/css');

$css = <<<CSS
html {
				/* Suppression des marges et remplissages :
				   Ecrasement des styles par défaut des divers navigateurs */
				margin           : 0 ;
				padding          : 0 ;
				background-color : transparent ;
			}

			body {
				/* Le corps du document */
				vertical-align   : text-bottom ;
				margin           : 0.3em ;
				padding          : 0.3em ;
				color            : #{$couleur4} ;
				background-color : #{$couleur1} ;
				padding          : 0 ;
				text-align       : center ;
			}

			body > * {
				text-align : left ;
			}

			#page {
				text-align          : left ;
				margin-left         : auto ;
				margin-right        : auto ;
				width               : 900px ;
				min-height          : 100% ;
				overflow            : visible ;
				position            : relative ;
				background-color    : #{couleur2};
				padding             : 10px ;
			}

			h1, h2, pre.code, fieldset legend, div, span.correction {
				/* Propriété spécique à Mozilla */
				-moz-border-radius : 5px ;
				/* Propriété spécique à Safari et Chrome */
				-webkit-border-radius : 5px ;
			}

			fieldset, #page {
				/* Propriété spécique à Mozilla */
				-moz-border-radius : 10px ;
				/* Propriété spécique à Safari et Chrome */
				-webkit-border-radius : 10px ;
			}

			h1 {
				margin-top          : 15px ;
				margin-bottom       : 5px ;
				padding-top         : 0 ;
				border              : 2px solid #{$couleur4} ;
				margin-right        : 20px  ;
				padding-left        : 10px  ;
				background-color    : #{$couleur1} ;
				color               : #{$couleur3} ;
				font-size           : 150% ;
				font-variant        : small-caps ;
			}

			a:link, a:visited, a:active {
				text-decoration  : underline ;
				color            : #{$couleur3} ;
				background-color : transparent ;
			} 

			a:link:hover, a:visited:hover {
				text-decoration  : underline ;
				color            : #{$couleur2} ;
			} 

			div.contenu {
				margin              : 20px ;
				margin-top          : 10px ;
				padding             : 10px ;
				border              : solid 2px #{$couleur3} ;
				background-color    : #{$couleur1} ;
				text-align          : justify ;
			}

			div.contenu p:first-letter {
				color          : #{$couleur3} ;
				text-transform : uppercase ;
				font-size      : 250% ;
				float          : left ;
				font-weight    : bold ;
			}

			#menustyle {
				float        : top ;
				text-align   : center ;
				margin       : auto ;
				padding-left : 0 ;
			}

			#menustyle li {
				display : inline ;
				padding-left : 0.3em ;
				padding-right : 0.3em ;
			}
CSS;

echo $css;

?>
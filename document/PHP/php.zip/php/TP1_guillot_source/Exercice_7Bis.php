﻿<?php
	
	function ferie($jour,$mois){
		$res = false;
		$jourFer = array(1,1,8,14,15,1,11,25);
		$moisFer = array(1,5,5,7,8,11,11,12);
		for($l=0;$l<8;$l++){
			if($jourFer[$l]==$jour && $moisFer[$l]==$mois ){$res=true;}
		}
		return $res;
	}
	
	$html = <<<HTML
		<html>
		<head>
			<title>
				Calendrier du jour
			</title>
			<style>
				table{
					border-collapse : collapse;
					text-align : right
				}
				td{
					border-right : 1px solid black;
					width : 30px;
					height : 25px;
					padding : 3px;
					font-size : 14px;
				}
				.lundi{
					border-left : 1px solid black;
				}
				.caseVert{
					background-color : rgb(190,255,190);
				}
				.entete{
					background-color : rgb(230,230,230);
					text-align : center;
				}
				div{
					display : inline-block;
					width : 220px;
					height : 210px;
					margin : 10px;
				}
			</style>
		</head>
		<body>
			<h1>
				Calendrier 
			</h1>
HTML;
	
	$date = time() ;
	$anneeAct = date("Y",$date);
	if(empty($_POST['mois'])){
		$mois = date("m",$date);
	}
	else{		
		$mois = $_POST['mois'];
	}
	if(empty($_POST['annee'])){
		$annee = date("Y",$date);
	}
	else{		
		$annee = $_POST['annee'];
	}
	setlocale(LC_ALL, 'fr_FR.utf8') ;
	$semaine = array('L', 'M', 'M', 'J', 'V', 'S', 'D');
	$moisTab = array();	
	$moisTabInt = array();
	for($k=1;$k<=12;$k++){
		$datetmp = mktime(0,0,0,$k,1,$annee);			
		$nom_mois = strftime("%B", $datetmp) ;
		$moisTab[] = $nom_mois;
		$moisTabInt[] = $k;
	}
	$datetmp = mktime(0,0,0,$mois,1,$annee);
	$premier_jour_mois = date('N', $datetmp) ;
	$nombre_jours_mois = date('t', $datetmp) ;
	$nom_mois = strftime("%B %Y", $datetmp) ;
	
	$html .= '<div><table>';
	$html .= '<tr class=\'entete\'><td class=\'lundi\' colspan=\'8\'><b>'.$nom_mois.'</b></td></tr><tr class=\'entete\'>';
	

	for($i=0;$i<7;$i++){
		if($i==0){$html .= "<td class='lundi'><b>".$semaine[$i]."</b></td>";}
		else{$html .= "<td><b>".$semaine[$i]."</b></td>";}
	}
	$html .= "</tr><tr>";
	$alpha = 0;
	for($i=0;$i<$premier_jour_mois-1;$i++){
		if($alpha==0){$html .= '<td class=\'lundi\'></td>';}
		else{$html .= '<td></td>';}
		$alpha++;
	}
	for($i=1;$i<=$nombre_jours_mois;$i++){
		if($alpha==0 && ferie($i,$mois)){$html .= '<td class=\'lundi\' style=\'background-color : rgba(255,0,0,0.5);\'>'.$i.'</td>';}
		elseif($alpha==0 && !ferie($i,$mois)){$html .= '<td class=\'lundi\'>'.$i.'</td>';;}
		elseif(($alpha==5||$alpha==6)&&!ferie($i,$mois)){$html .= '<td class=\'caseVert\'>'.$i.'</td>';}
		elseif(($alpha==5||$alpha==6)&&ferie($i,$mois)){$html .= '<td style=\'background-color : rgba(255,0,0,0.5);\'>'.$i.'</td>';}
		elseif(ferie($i,$mois)){$html .= '<td style=\'background-color : rgba(255,0,0,0.5);\'>'.$i.'</td>';}
		else{$html .= '<td>'.$i.'</td>';}
		$alpha++;
		if($alpha==7){	$html .= '</tr><tr>';
						$alpha = 0;}
	}
	for($i=$alpha;$i<7;$i++){
		if($alpha==0){$html .= '<td class=\'lundi\'></td>';}
		else{$html .= '<td></td>';}
		$alpha++;
	}
	$html .= <<<HTML
		</tr>
		</table></div>
		
HTML;
	$html .= '<form method=\'post\'><select name=\'mois\' size\'1\'>';
		for($i=0;$i<12;$i++){
			if($moisTabInt[$i]==$mois){
				$html .= '<option value='.$moisTabInt[$i].' selected>'.$moisTab[$i].'</option>';
			}
			else{
				$html .= '<option value='.$moisTabInt[$i].'>'.$moisTab[$i].'</option>';
			}
		}
	$html .= '</select>';
	
	$html .= '<select name=\'annee\' size\'1\'>';
		for($i=1900;$i<=$anneeAct;$i++){
			if($i == $annee){
				$html .= '<option value='.$i.' selected>'.$i.'</option>';
			}
			else{				
				$html .= '<option value='.$i.'>'.$i.'</option>';
			}
		}
	$html .= '</select><input type=\'submit\'></form>';
	

$html .= '</body></html>';
	

	
	
	
	
	
	
	echo $html;
?>
<?php
	echo '<table style=\'text-align:right;\'>';
	for($i=0;$i<=10;$i++){
		$multiple = $i;
		$res = $i*12;
		echo '<tr><td>'.$multiple.'</td><td>x</td><td>12</td><td>=</td><td>'.$res.'</td></tr>';
	}
	echo '</table>';

?>
﻿<?php
	$html = <<<HTML
		<html>
		<head>
			<title>
				Table de multiplication
			</title>
			<style>
				
			</style>
		</head>
		<body>
			
			<table style='text-align:right;'>
HTML;
	if(isset($_POST['nombre'])){
	for($i=0;$i<=10;$i++){
		$multiple = $i;
		$res = $i*$_POST['nombre'];
		$html.= '<tr><td>'.$multiple.'</td><td>x</td><td>'.$_POST['nombre'].'</td><td>=</td><td>'.$res.'</td></tr>';
	}
	$html.= '</table><a href=\'Exercice_8.html\'>RETOUR</a>';
	}
	echo $html;

?>
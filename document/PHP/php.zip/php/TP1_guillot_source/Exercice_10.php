<?php
	include 'fonction_calendrier.php';
	
	setlocale(LC_ALL, 'fr_FR.utf8') ;
	
	if(empty($_GET['annee'])){
		$date = time() ;
		$annee = date("Y",$date);
	}
	else{
		$annee = (int)$_GET['annee'];
	}
	
$html = <<<HTML
		<html>
		<head>
			<title>
				Calendrier du jour
			</title>
			<style>
				table{
					border-collapse : collapse;
					text-align : right
				}
				td{
					border-right : 1px solid black;
					width : 30px;
					height : 25px;
					padding : 3px;
					font-size : 14px;
				}
				.lundi{
					border-left : 1px solid black;
				}
				.caseVert{
					background-color : rgb(190,255,190);
				}
				.entete{
					background-color : rgb(230,230,230);
					text-align : center;
				}
				.moisCalendrier{
					display : inline-block;
					width : 210px;
					height : 210px;
					margin : 10px;
				}
				#calendrier{
					width : 920px;
					margin : auto;
					border : 2px solid grey;
				}
				#next{
					position : absolute;
					top : 100px;
					right : 20px;
				}
				
				#prev{
					position : absolute;
					top : 100px;
					left : 20px;
				}
				
				#next img,#prev img{
					width : 40px;
					height : 40px;
					border : 2px dotted grey;
					border-radius : 90%;
					
				}
				h1{
					text-align : center;
				}
				form{
					text-align : center;
				}
			</style>
		</head>
		<body>
			<h1>
				Calendrier 
			</h1>
HTML;
	$html .= '<form method=\'get\'><select name=\'annee\' size\'1\'>';
		for($i=1900;$i<=2100;$i++){
			if($i == $annee){
				$html .= '<option value='.$i.' selected>'.$i.'</option>';
			}
			else{				
				$html .= '<option value='.$i.'>'.$i.'</option>';
			}
		}
	$html .= '</select><input type=\'submit\'></form>';
	$html.=calendrier($annee); 
	
	$anneeP = $annee + 1;
	$anneeM = $annee -1;             
	$html .= "<div id='prev'><a href='Exercice_10.php?annee=$anneeM'><img src='prev.png'></a></div>";
	$html .= "<div id='next'><a href='Exercice_10.php?annee=$anneeP'><img src='next.png'></a></div>";
	
	

$html .= '</body></html>';
	
	
	
	
	
	
	echo $html;
?>
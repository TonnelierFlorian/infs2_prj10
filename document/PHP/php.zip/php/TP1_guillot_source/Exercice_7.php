﻿<?php
 $semaine = array('Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi','Dimanche');
 $html = <<<HTML
	<html>
		<head>
			<title>
				Liste déroulante
			</title>
		</head>
		<body>
HTML;

	$html .= '<form><select name=\'jour\' size\'1\'>';
	for($i=0;$i<7;$i++){
		$html .= '<option value='.$semaine[$i].'>'.$semaine[$i].'</option>';
	}
	$html .= '</select></form>';
	
	$html .= '<form>';
	for($i=0;$i<7;$i++){
		$html .= '<input type=\'radio\' name=\'semaine\' id=\'semaine'.$i.'\'>';
		$html .= '<label for=\'semaine'.$i.'\'>'.$semaine[$i].'</label><br>';
	}
	$html .= '</form>';
	
 $html .= <<<HTML
		</body>
	</html>
HTML;

echo $html;
?>
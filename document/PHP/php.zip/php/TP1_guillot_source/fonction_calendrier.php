﻿<?php

	function ferie($jour,$mois){
		$res = false;
		$jourFer = array(1,1,8,14,15,1,11,25);
		$moisFer = array(1,5,5,7,8,11,11,12);
		for($l=0;$l<8;$l++){
			if($jourFer[$l]==$jour && $moisFer[$l]==$mois ){$res=true;}
		}
		return $res;
	}
	
	function codeMois($mois,$annee){
		$html = '';
		$datetmp = mktime(0,0,0,$mois,1,$annee);
		$nom_mois = strftime("%B %Y", $datetmp) ; //Recupère le nom du mois
		$nom_mois=ucfirst($nom_mois);
		$semaine = array('L', 'M', 'M', 'J', 'V', 'S', 'D');
		$premier_jour_mois = date('N', $datetmp) ;
		$nombre_jours_mois = date('t', $datetmp) ;
		
		$html .= '<div class=\'moisCalendrier\'><table>';
		$html .= '<tr class=\'entete\'><td class=\'lundi\' colspan=\'8\'><b>'.$nom_mois.'</b></td></tr><tr class=\'entete\'>'; //Affiche le nom du mois
		
		for($i=0;$i<7;$i++){ //Créer l'entete du tableau
			if($i==0){$html .= "<td class='lundi'><b>".$semaine[$i]."</b></td>";}
			else{$html .= "<td><b>".$semaine[$i]."</b></td>";}
		}
		
		$html .= "</tr><tr>";
		$alpha = 0; //Compteur
		
		for($i=0;$i<$premier_jour_mois-1;$i++){ //Créer les cases vides au départ
			if($alpha==0){$html .= '<td class=\'lundi\'></td>';}
			else{$html .= '<td></td>';}
			$alpha++;
		}
		
		for($i=1;$i<=$nombre_jours_mois;$i++){ //Créer les cases numérotées
			if($alpha==0 && ferie($i,$mois)){$html .= '<td class=\'lundi\' style=\'background-color : rgba(255,0,0,0.5);\'>'.$i.'</td>';}
			elseif($alpha==0 && !ferie($i,$mois)){$html .= '<td class=\'lundi\'>'.$i.'</td>';;}
			elseif(($alpha==5||$alpha==6)&&!ferie($i,$mois)){$html .= '<td class=\'caseVert\'>'.$i.'</td>';}
			elseif(($alpha==5||$alpha==6)&&ferie($i,$mois)){$html .= '<td style=\'background-color : rgba(255,0,0,0.5);\'>'.$i.'</td>';}
			elseif(ferie($i,$mois)){$html .= '<td style=\'background-color : rgba(255,0,0,0.5);\'>'.$i.'</td>';}
			else{$html .= '<td>'.$i.'</td>';}
			$alpha++;
			if($alpha==7&&$i!=$nombre_jours_mois){	$html .= '</tr><tr>';
							$alpha = 0;}
		}
		
		for($i=$alpha;$i<7;$i++){  //Créer les cases vides à la fin
			if($alpha==0){$html .= '<td class=\'lundi\'></td>';}
			else{$html .= '<td></td>';}
			$alpha++;
		}
		
		$html .='</tr></table></div>';
		return $html;
	}
	
	function calendrier($annee){
		$html = '<div id=\'calendrier\'>';
		for($i=1;$i<=12;$i++){
			$html.=codeMois($i,$annee);
		}
		$html.= '</div>';
		return $html;
	}
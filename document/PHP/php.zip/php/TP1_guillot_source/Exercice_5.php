﻿<?php
	
	$html = <<<HTML
		<html>
		<head>
			<title>
				Calendrier du jour
			</title>
			<style>
				table{
					border-collapse : collapse;
					text-align : right
				}
				td{
					border-right : 1px solid black;
					width : 30px;
					height : 25px;
					padding : 3px;
					font-size : 14px;
				}
				.lundi{
					border-left : 1px solid black;
				}
				.caseVert{
					background-color : rgb(190,255,190);
				}
				.entete{
					background-color : rgb(230,230,230);
					text-align : center;
				}
				div{
					display : inline-block;
					width : 220px;
					height : 210px;
					margin : 10px;
				}
			</style>
		</head>
		<body>
			<h1>
				Calendrier du mois actuel
			</h1>
HTML;
	
for($j=1;$j<=12;$j++){	
	
	setlocale(LC_ALL, 'fr_FR.utf8') ;
	$semaine = array('L', 'M', 'M', 'J', 'V', 'S', 'D') ;
	$date = time() ;
	$annee = date("Y",$date);
	$mois = date("m",$date);
	$datetmp = mktime(0,0,0,$j,1,$annee);
	$premier_jour_mois = date('N', $datetmp) ;
	$nombre_jours_mois = date('t', $datetmp) ;
	$nom_mois = strftime("%B %Y", $datetmp) ;
	
	$html .= '<div><table>';
	$html .= '<tr class=\'entete\'><td class=\'lundi\' colspan=\'8\'><b>'.$nom_mois.'</b></td></tr><tr class=\'entete\'>';
	for($i=0;$i<7;$i++){
		if($i==0){$html .= "<td class='lundi'><b>".$semaine[$i]."</b></td>";}
		else{$html .= "<td><b>".$semaine[$i]."</b></td>";}
	}
	$html .= "</tr><tr>";
	$alpha = 0;
	for($i=0;$i<$premier_jour_mois-1;$i++){
		if($alpha==0){$html .= '<td class=\'lundi\'></td>';}
		else{$html .= '<td></td>';}
		$alpha++;
	}
	for($i=1;$i<=$nombre_jours_mois;$i++){
		if($alpha==0){$html .= '<td class=\'lundi\'>'.$i.'</td>';}
		elseif($alpha==5||$alpha==6){$html .= '<td class=\'caseVert\'>'.$i.'</td>';}
		else{$html .= '<td>'.$i.'</td>';}
		$alpha++;
		if($alpha==7){	$html .= '</tr><tr>';
						$alpha = 0;}
	}
	for($i=$alpha;$i<7;$i++){
		if($alpha==0){$html .= '<td class=\'lundi\'></td>';}
		else{$html .= '<td></td>';}
		$alpha++;
	}
	$html .= <<<HTML
		</tr>
		</table></div>
HTML;
	
}

$html .= '</body></html>';
	

	
	
	
	
	
	
	echo $html;
?>
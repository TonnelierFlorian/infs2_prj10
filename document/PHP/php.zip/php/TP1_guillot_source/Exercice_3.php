<?php	
	$class = null;
	$html = <<<HTML
	<html>
		<head>
			<title>
				Table de pythagore
			</title>
			<style>
				td{
					width : 30px;
					height : 30px;
					border : 1px solid black;
				}
				table{					
					border-collapse : collapse;
				}
				.beige{
					background-color : floralwhite;
				}
				.gris{
					background-color : grey;
				}
			</style>
		</head>
		<body>
			<h1>
				Table de pythagore
			</h1>
			<table style='text-align:right;'>
HTML;
	$html .= <<<HTML
	<tr>
		<td>x</td>
HTML;
	for($i=0;$i<=10;$i++){
		if($i%2==0){
			$class = 'class=\'beige\'';
		}
		else{
			$class = null;
		}
		$html .= '<td '.$class.'><b>'.$i.'</b></td>';
	}
	$html .= '</tr>';
	for($i=0;$i<=10;$i++){
		if($i%2==0){
			$class = 'class=\'beige\'';
		}
		else{
			$class = null;
		}
		$html .= '<tr><td '.$class.'><b>'.$i.'</b></td>';
		for($j=0;$j<=10;$j++){
			if($i%2==0 || $j%2==0){
				$class = 'class=\'beige\'';
				if($i%2==0 && $j%2==0){
				$class = 'class=\'gris\'';
				}
			}
			else{
				$class = null;
			}
			
			$html .= '<td '.$class.'>'.($i*$j).'</td>';
		}
		$html .= '</tr>';
	}
	$html .= <<<HTML
			</table>
		</body>
	</html>
HTML;
echo $html;

	

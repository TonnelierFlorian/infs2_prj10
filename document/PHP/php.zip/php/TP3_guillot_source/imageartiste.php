<?php

require_once("Cover.class.php");
require_once("Album.class.php");
require_once("Artist.class.php");
require_once 'gdimage.class.php' ;

if(isset($_GET['id'])){
	$id=$_GET['id'];
	$artists : 
	
}
else{
	echo ("Pas de jaquette trouvée");
}
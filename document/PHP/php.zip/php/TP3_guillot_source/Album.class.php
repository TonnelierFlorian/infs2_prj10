<?php

require_once 'myPDO.class.php' ;
require_once 'Entity.class.php' ;
myPDO::setConfiguration('mysql:host=mysql;dbname=cutron01_cdobj;charset=utf8', 'web', 'web') ;

class Album extends Entity {
    protected $year   = null ;
    protected $genre  = null ;
    protected $artist = null ;
    protected $cover  = null ;

    // Usine pour fabriquer une instance à partir d'un identifiant
    public static function createFromId($id){
	
		$pdo = myPDO::getInstance() ;

		$stmt = $pdo->prepare("SELECT * FROM album WHERE id=?");
		$stmt->execute(array($id));
		
		$stmt->setFetchMode(PDO::FETCH_CLASS, 'Album');
		if (($object = $stmt->fetch()) !== false) {
			return $object;
		}
		else{
			throw new Exception('Album introuvable');
		}
    }

    public function getYear() {
		return $this->year;
    }
	
    public function getArtist() {
		return $this->artist;
    }
	
    public function getCoverId() {
		return $this->cover;
    }
	
    public function getCover() {
       require_once("Cover.class.php");
	   $imgCover = Cover::createFromID($this->cover);
	   return $imgCover->getJPEG();
    }

    // Retourner les pistes d'un album par ordre de numéro de piste
    public function getTracks() {
        require_once("Track.class.php");
        $tracks = array();
		
		$pdo = myPDO::getInstance() ;
		$stmt = $pdo->query(<<<SQL
			SELECT *
			FROM track
			WHERE album={$this->id}
			ORDER BY disknumber,number
SQL
		);
		$stmt->setFetchMode(PDO::FETCH_CLASS, 'Track');
		while(($objet = $stmt->fetch()) !== false){
			$tracks[] = $objet;
		}
		
		return $tracks;
		
    }	
    
}
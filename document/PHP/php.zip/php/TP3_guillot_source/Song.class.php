<?php

require_once 'myPDO.class.php' ;
require_once 'Entity.class.php' ;

class Song extends Entity {

    /**
     * Usine pour fabriquer une instance à partir d'un identifiant
     * Les données sont issues de la base de données
     * @param int $id identifiant BD du morceau à créer
     * @return Song instance correspondant à $id
     * @throws Exception si le morceau ne peut pas être trouvé dans la base de données
     */
    public static function createFromID($id) {
	
		$pdo = myPDO::getInstance() ;

		$stmt = $pdo->prepare("SELECT * FROM song WHERE id=?");
		$stmt->execute(array($id));
		
		$stmt->setFetchMode(PDO::FETCH_CLASS, 'Song');
		if (($object = $stmt->fetch()) !== false) {
			return $object;
		}
	
    }
}
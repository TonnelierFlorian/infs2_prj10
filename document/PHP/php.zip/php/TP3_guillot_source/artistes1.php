<?php

require_once("Artist.class.php");
require_once("Webpage.class.php");

$artists = Artist::getAll();

$p = new WebPage() ;
$p->appendCssUrl('/ressources/css/php.css');
$p->setTitle('Tous les artistes de la base de donnée :') ;
$p->appendToHead('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">');
$p->appendContent(<<<HTML
	<h1>Artistes</h1>
	<ul>
HTML
) ;

foreach($artists as $artist){
	$name = $artist->getName();
	$id = $artist->getId();
	$p->appendContent("<li><a href='albums2.php?id=$id'>$name</a></li>");
}
$p->appendContent("</ul>");
echo $p->toHtml();
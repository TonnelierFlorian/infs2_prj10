<?php

require_once 'Webpage.class.php' ;
require_once 'Album.class.php' ;
require_once 'Artist.class.php' ;

$artist='1';
if(isset($_GET['artist'])){
	$artist = $_GET['artist'];
}

$p = new WebPage() ;
$p->setTitle('Ma enième page Web objet') ;
$p->appendToHead('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">');
$p->appendContent(<<<HTML
    <h1>Albums de <i>{$artist}</i></h1>
	<ul>
HTML
) ;

$pdo = myPDO::getInstance() ;

$stmt2 = $pdo->prepare("SELECT id,name,year FROM album WHERE artist = ? ORDER BY year");
$stmt2->execute(array($artist));

while(($ligne2 = $stmt2->fetch()) !== false){
	$p -> appendContent('<li>'.$ligne2['year'].' - '.$ligne2['name']);
}

$p->appendContent('</ul>');

echo $p->toHTML() ;
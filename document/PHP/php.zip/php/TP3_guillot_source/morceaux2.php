<?php

require_once 'Webpage.class.php' ;
require_once 'Album.class.php' ;
require_once 'Artist.class.php' ;
require_once 'Track.class.php';
require_once 'Song.class.php' ;

$p = new WebPage() ;

if(isset($_GET['id'])){

	$id = $_GET['id'];
	$album = Album::createFromID($id);
	$tracks = $album->getTracks();
	$songs = array();
	$artist = Artist::createFromID($album->getArtist());
	
	
	$name = $artist->getName();
	$p->setTitle("Voici les albums de $name") ;
$p->appendCssUrl('/ressources/css/php.css');
	$p->appendToHead('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">');
	$p->appendContent(<<<HTML
		<h1>Albums de $name</h1>
HTML
	) ;
	
	
	
	foreach($tracks as $track){
		$idSong = $track->getSong();
		$song = Song::createFromID($idSong);
		$idTrack = $track->getFormatedNumber();
		$name = $song->getName();
		$duree = $track->getFormatedDuration();
		$p->appendContent("<li>$idTrack - $name - ($duree)</li>");
	}
	$idCover = $album->getCoverId();
	$p->appendContent("<img src='imagealbum.php?id=$idCover'>");
}
else{
	$p->setTitle("Voici les musiques de l'albume ?") ;
$p->appendCssUrl('/ressources/css/php.css');
	$p->appendToHead('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">');
	$p->appendContent("<p>Pas d'albums pour cet artiste, verifiez le nom de l'artiste.</p>");
}

echo $p->toHTML();
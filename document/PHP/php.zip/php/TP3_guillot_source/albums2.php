<?php

require_once 'Webpage.class.php' ;
require_once 'Album.class.php' ;
require_once 'Artist.class.php' ;
require_once("Cover.class.php");

$p = new WebPage() ;


if(isset($_GET['id'])){

	
	try{
		$id = $_GET['id'];
		$artist = Artist::createFromID($id);
		$name = $artist->getName();
		$p->setTitle("Voici les albums de $name") ;
		
$p->appendCssUrl('/ressources/css/php.css');
		$p->appendToHead('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">');
		$p->appendContent(<<<HTML
			<h1>Albums de $name</h1>
HTML
		) ;
		
		$albums = $artist->getAlbums();	
		$p->appendContent("<div id='contenu'>");
		foreach($albums as $album){		
			$year = $album->getYear();
			$name = $album->getName();
			$id = $album->getId();
			$p->appendContent("<div class='album'><a href='morceaux2.php?id=$id'>");
			$idCover = $album->getCoverId();
			$p->appendContent("<img src='imagealbum.php?id=$idCover'>");
			$p->appendContent("<span>$year - $name</span>");
			$p->appendContent("</a></div>");
		}
		$p->appendContent("</div>");
	}
	catch(Exception $e){
		$p->setTitle("Erreur $id") ;
		
$p->appendCssUrl('/ressources/css/php.css');
		$p->appendToHead('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">');
		$p->appendContent("<p>Pas d'albums pour cet artiste, vérifiez le nom de l'artiste.</p>");
	}
	

}
else{
	$p->setTitle("Voici les albums de ?") ;
	$p->appendToHead('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">');
	$p->appendContent("<p>Pas d'albums pour cet artiste, vérifiez le nom de l'artiste.</p>");
}

echo $p->toHTML();
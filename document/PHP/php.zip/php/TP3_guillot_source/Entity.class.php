<?php

abstract class Entity {
    /// Identifiant
    protected $id = null ;
    /// Nom
    protected $name = null ;

    /// Constructeur non accessible
    private function __construct() {
        // Rien de particulier à écrire
    }

    /// Accesseur sur id
    public function getId() {
		return $this->id;
    }

    /// Accesseur sur name
    public function getName() {
		return $this->name;
    }
}
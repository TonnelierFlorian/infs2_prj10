<?php

require_once 'Webpage.class.php' ;
require_once 'Artist.class.php' ;

$p = new WebPage() ;

$p->setTitle('Ma enième page Web objet') ;

$p->appendToHead('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">');

$p->appendContent(<<<HTML
    <h1>Artistes</h1>
	<ul>
HTML
) ;

$art = Artist::getAll();
foreach($art as $artiste){
	$p -> appendContent('<li>'.$artiste.'</li>');
}

$p -> appendContent('</ul>');

echo $p->toHTML() ;
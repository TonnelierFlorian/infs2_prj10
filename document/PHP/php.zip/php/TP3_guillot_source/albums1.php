<?php

require_once 'Webpage.class.php' ;
require_once 'Album.class.php' ;
require_once 'Artist.class.php' ;

$p = new WebPage() ;


if(isset($_GET['id'])){

	$id = $_GET['id'];
	$artist = Artist::createFromID($id);
	
	$name = $artist->getName();
	$p->setTitle("Voici les albums de $name") ;
	
$p->appendCssUrl('/ressources/css/php.css');
	$p->appendToHead('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">');
	$p->appendContent(<<<HTML
		<h1>Albums de $name</h1>
		<ul>
HTML
	) ;
	
	$albums = $artist->getAlbums();	
	foreach($albums as $album){
		$year = $album->getYear();
		$name = $album->getName();
		$id = $album->getId();
		$p->appendContent("<li><a href='morceaux1.php?id=$id'>$year - $name</a></li>");
	}
	
	$p->appendContent("</ul>");
}
else{
	$p->setTitle("Voici les albums de ?") ;
	
$p->appendCssUrl('/ressources/css/php.css');
	$p->appendToHead('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">');
	$p->appendContent("<p>Pas d'albums pour cet artiste, verifiez le nom de l'artiste.</p>");
}

echo $p->toHTML();
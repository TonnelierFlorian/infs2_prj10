<?php

require_once 'Webpage.class.php' ;

$p = new WebPage() ;

$p->setTitle('Ma première page Web objet') ;

$p->appendToHead('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">');
$p->appendCssUrl("/css/style.css") ;
$p->appendCSS(<<<CSS
    p em {
        background-color : green ;
    }
CSS
) ;

$p->appendJS(<<<JAVASCRIPT
    window.onload = function () {
        window.alert('Ça fonctionne !') ;
    }
JAVASCRIPT
) ;

$p->appendContent(<<<HTML
    <h1>Ma première page Web en PHP objet !</h1>
    <p>Vous êtes en train de lire ma première page Web écrite en <em>PHP objet</em>.
HTML
) ;

echo $p->toHTML() ;
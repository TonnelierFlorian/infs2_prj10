<?php

require_once 'myPDO.class.php' ;

class Track {
    private $album = null ;
    private $song = null ;
    private $number = null ;
    private $disknumber = null ;
    private $duration = null ;

    /**
     * Accesseur sur duration
     * @return string Durée du morceau en secondes
     */
    public function getDuration() {
		return $this->duration;
    }

    /**
     * Accesseur sur duration
     * @return string Durée du morceau au format mm:ss
     */
    public function getFormatedDuration() {
		$sec = $this->duration;
		$min = 0;
		for($i = 0; $sec>60;$i++){
			$min ++;
			$sec -= 60;
		}
		if($min < 10){$min = '0'.$min;}
		if($sec < 10){$sec = '0'.$sec;}
		$res = "$min:$sec";
		return $res;
    }

    /**
     * Accesseur sur number
     * @return string Numéro de piste
     */
    public function getNumber() {
		return $this->number;
    }

    /**
     * Accesseur sur number
     * @return string Numéro de piste sur deux chiffres
     */
    public function getFormatedNumber() {
		$res = $this->number + 100 * $this->disknumber;
		if($res < 10){$res = '0'.$res;}
		return $res;
    }

    /**
     * Accesseur sur album
     * @return Album Instance de Album
     */
    public function getAlbum() {
		return $this->album;
    }

    /**
     * Accesseur sur song
     * @return Song Instance de Song
     */
    public function getSong() {
		return $this->song;
    }
}
<?php

require_once 'myPDO.class.php' ;

myPDO::setConfiguration('mysql:host=mysql;dbname=cutron01_cdobj;charset=utf8', 'web', 'web') ;

$pdo = myPDO::getInstance() ;

$stmt = $pdo->prepare(<<<SQL
    SELECT name
    FROM artist
    ORDER BY name
SQL
) ;

$stmt->execute() ;

while (($ligne = $stmt->fetch()) !== false) {
        echo "<p>{$ligne['name']}\n" ;
}
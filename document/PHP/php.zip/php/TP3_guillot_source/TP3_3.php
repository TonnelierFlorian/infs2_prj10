<?php
require_once 'Artist.class.php' ;

$art = Artist::getAll();
foreach($art as $coucou){
	echo $coucou;
}